This sample code is distributed from http://code.google.com/p/google-mail-oauth2-tools/ under the Apache License 2.0.

The Apache License 2.0 is available from
http://www.apache.org/licenses/LICENSE-2.0.

For instructions on using this sample code, see:
http://code.google.com/p/google-mail-oauth2-tools/wiki/JavaSampleCode
